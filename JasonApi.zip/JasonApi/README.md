# <p align="center" style="color:#cb3349" > [<< TH3BOSS >> V23 (Final Version)](https://telegram.me/llDEV1ll)

 <p align="center" style="color: #14635c;" > بوت الزعيم الاقوى والاحدث لحمايه المجموعات في التلكرام
<p align="center"><img src="زعيم.jpg" alt="بوت زعيم" title="بوت زعيم">

***

# <p align="center" style="color: #14635c;" > التنصيب بكود واحد
```sh
git clone https://github.com/moody2020/TH3BOSS.git && cd TH3BOSS && chmod +x install.sh &&./install.sh
```


<br>

# <p align="center" style="color: #14635c;" >  تنصيب سورس الزعيم الاصدار 23 والاخير

◈￤  افتـح ترمنـــأل وخلي هاي
```sh
redis-server
```
◈￤  اتركه مفتوح وافتح ترمنال ثاني وخلي
```sh
git clone https://github.com/moody2020/TH3BOSS.git
```
◈￤  وراها هاي
```sh
cd TH3BOSS
```
◈￤  وراها هاي 
```sh
cd TH3BOSS
```
◈￤  وراها هاي 
```sh
chmod +x install.sh
```
◈￤  وراها هاي 
```sh
./install.sh
```
◈￤للاستفسار راسلني 
```sh
@TH3BOSS
```
◈￤للاستفسار راسلني 
```sh
@lBOSSl
```
##  [◈￤انتظر قليلا ثم يطلب منك ايدي وتوكن خلي ايديك والتوكن مبروك عليك افضل بوت بالتلكرام](https://telegram.me/llDEV1ll)
# <p align="center"> ◈￤  للاستفسار راسلني 

  [Mohammed Hisham](https://telegram.me/TH3BOSS) <br>
  
  [TH3BOSS](https://telegram.me/LBOSSL) <br>
  
  [CH - TH3BOSS](https://telegram.me/LLDEV1LL) <br>
  
  [Group Support](https://telegram.me/lBOSSl)<br>
